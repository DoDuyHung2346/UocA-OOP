public class Student {
    private String name,id,group,email;
    /**
     * Constructor 1
     */
    Student() {
        // TODO:
        this.name="Student";
        this.id="000";
        this.group="K62CB";
        this.email="uet@vnu.edu.vn";
    }

    /**
     * Constructor 2
     * @param n
     * @param sid
     * @param em
     */
    Student(String name, String id, String email) {
        // TODO:
        this.name=name;
        this.id=id;
        this.email=email;
        this.group="K62CB";
    }

    /**
     * Constructor 3
     * @param s
     */
    Student(Student s) {
        // TODO:
        if (s != null) {
            this.name = s.name;
            this.id = s.id;
            this.group = s.group;
            this.email = s.email;
        } else {
            this.name = "";
            this.id = "";
            this.group = "";
            this.email = "";
        }
    }
    public String getName()
    {
        return this.name;
    }
    public void setName(String n)
    {
        this.name=n;
    }
    public String getInfo()
    {
        String s = this.name+" - " +this.id + " - " + this.group + " - " +this.email;
        return s;
    }
    public String getGroup()
    {
        return this.group;
    }
    public String getId()
    {
        return this.id;
    }
    public String getEmail()
    {
        return this.email;
    }
}


