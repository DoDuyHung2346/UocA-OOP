public class StudentManagement {

    // TODO: khai bao thuoc tinh students la array chua cac doi tuong thuoc lop Student (max. 100)
    private Student students[] = new Student[100];
    private int size=0;
    public static boolean sameGroup(Student s1, Student s2) {
        // TODO:
        return s1.getGroup().equals(s2.getGroup());
    }

    public void addStudent(Student newStudent){
        // TODO:
        if (size < 100) {
            students[size] = new Student(newStudent);
            size++;
        }
    }

    /**
     * All info.
     *
     * @return string
     */

    public String studentsByGroup() {
        // TODO:
        int idx=0;
        String s[]=new String[100];
        if(students[0]!=null)s[0]=students[0].getGroup();
        for(int i=1;i<size;i++)
        {
            if(students[i]!=null && !students[i].getGroup().equals(s[idx])){
                idx++;
                s[idx]=students[i].getGroup();
            }
        }
        String xau="";
        for(int i=0;i<=idx;i++)
        {
            xau=xau+s[i]+"\n";
            for(int j=0;j<size;j++) {
                if (students[j] != null && students[j].getGroup().equals(s[i])) {
                    xau = xau + students[j].getName() + " - " + students[j].getId() + " - " + students[j].getGroup() + " - " + students[j].getEmail()+"\n";
                }
            }
        }
        return xau;
    }

    /**
     * remove student.
     *
     * @param id of student to be removed.
     */

    public void removeStudent(String id) {
        // TODO:
        for(int i=0;i<size;i++)
        {
            if(students[i].getId().equals(id))
            {
                for(int j=i;j<size - 1;j++) {
                    students[j] =students[j + 1];
                }
                students[size-1]=null;
                size--;
                break;
            }
        }
    }
}
